package com.hisba.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.widget.*;import java.text.SimpleDateFormat;import java.util.*;

public class MainActivity extends Activity {
  final int BG=Color.rgb(7,10,13), SUR=Color.rgb(16,22,28), SUR2=Color.rgb(21,29,37), GOLD=Color.rgb(242,169,59), TEXT=Color.rgb(244,241,233), MUTED=Color.rgb(155,165,175), GREEN=Color.rgb(40,209,124), RED=Color.rgb(255,77,94);
  LinearLayout root,content; SharedPreferences sp; ArrayList<Player> players=new ArrayList<>(); ArrayList<Round> rounds=new ArrayList<>(); String gameType="ورق"; int maxRounds=5; int roundNo=1;
  static class Player{String name;int total;Player(String n){name=n;}}
  static class Round{int no;int[] scores;Round(int n,int[] s){no=n;scores=s;}}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);sp=getSharedPreferences("hisba",0); showHome();}
  TextView tv(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(z);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(14,8,14,8);return t;}
  Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(15);b.setAllCaps(false);b.setBackground(round(SUR2,22));b.setPadding(12,4,12,4);return b;}
  GradientDrawable round(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);g.setStroke(1,Color.rgb(55,65,74));return g;}
  TextView goldTitle(String s){TextView t=tv(s,26);t.setTextColor(GOLD);t.setGravity(Gravity.CENTER);t.setTypeface(null,1);return t;}
  void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);setContentView(root);
    LinearLayout bar=new LinearLayout(this);bar.setPadding(10,8,10,4);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    Button back=btn("‹");back.setTextSize(28);back.setBackgroundColor(Color.TRANSPARENT);back.setOnClickListener(v->showHome());bar.addView(back,new LinearLayout.LayoutParams(55,55));TextView tt=goldTitle(title);bar.addView(tt,new LinearLayout.LayoutParams(0,58,1));TextView crown=tv("♛",26);crown.setTextColor(GOLD);bar.addView(crown,new LinearLayout.LayoutParams(55,55));root.addView(bar);
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(18,8,18,18);ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); }
  void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2));}
  TextView section(String s){TextView t=tv(s,14);t.setTextColor(MUTED);t.setPadding(4,16,4,6);return t;}
  void showHome(){base("حِسبة");content.removeAllViews();TextView sub=tv("سجّل اللعب واحسب النقاط بسهولة",15);sub.setTextColor(MUTED);sub.setGravity(Gravity.CENTER);add(sub);add(space(12));
    Button card=btn("♠  لعبة الورق   ›");card.setTextSize(19);card.setOnClickListener(v->{gameType="ورق";showSetup();});add(card);add(space(12));
    Button dom=btn("⚄  الدومينو   ›");dom.setTextSize(19);dom.setOnClickListener(v->{gameType="دومينو";showSetup();});add(dom);add(space(18));
    Button hist=btn("◷  الألعاب السابقة");hist.setOnClickListener(v->showHistory());add(hist);add(space(8));
    Button settings=btn("⚙  الإعدادات");settings.setOnClickListener(v->showSettings());add(settings);
  }
  Space space(int h){Space s=new Space(this);s.setMinimumHeight(h);return s;}
  void showSetup(){base("إنشاء لعبة جديدة");content.removeAllViews();add(section("نوع اللعبة"));add(tv("اللعبة المختارة: "+gameType,18));add(section("اللاعبون"));
    players.clear();int saved=sp.getInt("lastPlayers",4);for(int i=0;i<saved;i++)players.add(new Player(i==0?"حاتم":i==1?"أحمد":i==2?"علي":"سجاد"));
    LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setTag("players");add(list);refreshPlayerFields(list);
    Button ap=btn("＋ إضافة لاعب");ap.setOnClickListener(v->{if(players.size()<8){players.add(new Player("لاعب "+(players.size()+1)));refreshPlayerFields(list);}});add(ap);
    add(section("عدد الجولات"));LinearLayout rg=new LinearLayout(this);rg.setGravity(Gravity.CENTER);for(int n:new int[]{3,5,7}){Button x=btn(""+n);x.setOnClickListener(v->{maxRounds=n;for(int i=0;i<rg.getChildCount();i++)rg.getChildAt(i).setAlpha(.55f);v.setAlpha(1);});rg.addView(x,new LinearLayout.LayoutParams(0,58,1));}add(rg);
    add(space(18));Button start=btn("بدء اللعبة  ▶");start.setTextSize(18);start.setTextColor(Color.BLACK);start.setBackground(round(GOLD,24));start.setOnClickListener(v->{for(Player p:players){p.total=0;}rounds.clear();roundNo=1;showRound();});add(start);
  }
  void refreshPlayerFields(LinearLayout list){list.removeAllViews();for(int i=0;i<players.size();i++){final int k=i;EditText e=new EditText(this);e.setText(players.get(i).name);e.setTextColor(TEXT);e.setTextSize(16);e.setSingleLine();e.setHint("اسم اللاعب");e.setBackground(round(SUR,18));e.setPadding(16,4,16,4);e.setOnFocusChangeListener((v,f)->{if(!f)players.get(k).name=e.getText().toString().trim();});list.addView(e,new LinearLayout.LayoutParams(-1,56));Space spc=space(7);list.addView(spc);}}
  void showRound(){base("الجولة "+roundNo);content.removeAllViews();TextView prog=tv(roundNo+" / "+maxRounds,13);prog.setGravity(Gravity.CENTER);prog.setTextColor(MUTED);add(prog);add(section("أدخل نقاط الجولة"));
    ArrayList<EditText> inputs=new ArrayList<>();for(int i=0;i<players.size();i++){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(8,5,8,5);row.setBackground(round(SUR,18));TextView n=tv(players.get(i).name,17);row.addView(n,new LinearLayout.LayoutParams(0,62,1));EditText e=new EditText(this);e.setTextColor(TEXT);e.setTextSize(18);e.setGravity(Gravity.CENTER);e.setInputType(2|8192);e.setHint("0");e.setBackground(round(SUR2,14));row.addView(e,new LinearLayout.LayoutParams(105,54));inputs.add(e);add(row);add(space(7));}
    TextView rule=tv("ملاحظة: كل لاعب يحصل على 0 تُحسب له -25 في كل جولة.",13);rule.setTextColor(MUTED);rule.setPadding(8,16,8,16);add(rule);
    Button save=btn(roundNo<maxRounds?"حفظ الجولة  ✓":"إنهاء اللعبة  ✓");save.setTextSize(17);save.setTextColor(Color.BLACK);save.setBackground(round(GOLD,24));save.setOnClickListener(v->{int[] s=new int[players.size()];for(int i=0;i<s.length;i++){String q=inputs.get(i).getText().toString().trim();int val=q.isEmpty()?0:Integer.parseInt(q);s[i]=(val==0?-25:val);players.get(i).total+=s[i];}rounds.add(new Round(roundNo,s));if(roundNo<maxRounds){roundNo++;showRound();}else showResult();});add(save);
  }
  void showResult(){base("ملخص اللعبة");content.removeAllViews();Player winner=players.get(0);for(Player p:players)if(p.total>winner.total)winner=p;TextView w=goldTitle("♛  "+winner.name);add(w);TextView wt=tv("المتصدر — "+winner.total+" نقطة",17);wt.setGravity(Gravity.CENTER);add(wt);add(space(14));
    for(Player p:players){LinearLayout r=new LinearLayout(this);r.setPadding(12,4,12,4);r.setBackground(round(SUR,16));TextView n=tv(p.name,16);r.addView(n,new LinearLayout.LayoutParams(0,56,1));TextView sc=tv((p.total>=0?"+":"")+p.total,18);sc.setGravity(Gravity.CENTER);sc.setTextColor(p.total>=0?GREEN:RED);r.addView(sc,new LinearLayout.LayoutParams(100,56));add(r);add(space(7));}
    Button again=btn("لعبة جديدة");again.setOnClickListener(v->showSetup());add(again);add(space(8));Button home=btn("العودة للرئيسية");home.setOnClickListener(v->showHome());add(home);sp.edit().putInt("lastPlayers",players.size()).apply();
  }
  void showHistory(){base("الألعاب السابقة");content.removeAllViews();String h=sp.getString("history","");if(h.isEmpty()){TextView e=tv("لا توجد ألعاب محفوظة بعد",17);e.setGravity(Gravity.CENTER);add(e);return;}for(String line:h.split("\\n")){if(line.trim().isEmpty())continue;TextView t=tv(line,15);t.setBackground(round(SUR,16));add(t);add(space(7));}}
  void showSettings(){base("الإعدادات");content.removeAllViews();add(btn("المظهر الداكن  ✓"));add(space(8));Button clear=btn("حذف سجل الألعاب");clear.setOnClickListener(v->{sp.edit().remove("history").apply();Toast.makeText(this,"تم حذف السجل",Toast.LENGTH_SHORT).show();});add(clear);add(space(8));add(tv("حِسبة\nالإصدار 1.0.0",14));}
  @Override public void onBackPressed(){showHome();}
}
